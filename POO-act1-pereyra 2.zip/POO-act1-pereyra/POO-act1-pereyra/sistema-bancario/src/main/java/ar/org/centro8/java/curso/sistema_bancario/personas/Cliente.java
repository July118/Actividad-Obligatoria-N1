package ar.org.centro8.java.curso.sistema_bancario.personas;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor

public abstract class Cliente {
    private int numeroCliente;
}


